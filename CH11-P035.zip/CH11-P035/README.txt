SBL 1.0 resolved page rendering package
Render target: CH11-P035
Entry file: CH11-P035.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Academy-Uniform-Male.png
  Assets/Adnil-production-sheet.png
  Assets/Academy-Uniform-Female.png
  Assets/Naandeen-production-sheet.png
  Assets/Midori-Temple-Robes.png
  Assets/Kenee-Character-Sheet.png
  Assets/Ashiba-Academy-Assembly-Hall-Podium-Reference-Sheet.png
  Assets/Beli-production-sheet.png
  Assets/Ashire-Character-Sheet.png
  Assets/Midori-Production-Academy.png
  Assets/Buren-Character-Sheet.png
  Assets/Zarleen-age-19-20.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
