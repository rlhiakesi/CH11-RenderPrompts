SBL 1.0 resolved page rendering package
Render target: CH11-P003
Entry file: CH11-P003.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Seraphine-character-sheet.png
  Assets/Midori-Production-Academy.png
  Assets/Ashire-Office-Academy-Interior-Reference-Sheet.png
  Assets/Midori-Temple-Robes.png
  Assets/Ashire-Character-Sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
