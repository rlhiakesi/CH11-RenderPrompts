SBL 1.0 resolved page rendering package
Render target: CH11-P006
Entry file: CH11-P006.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Midori-Temple-Robes.png
  Assets/Midori-Dormitory-Environment-Reference.png
  Assets/Ashiba-Academy-Mana-Operated-Doors.png
  Assets/Midori-Production-Academy.png
  Assets/Ashire-Character-Sheet.png
  Assets/Adnil-production-sheet.png
  Assets/Zarleen-age-19-20.png
  Assets/Seraphine-character-sheet.png
  Assets/Dorm Floor Plan.png
  Assets/Naandeen-production-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
