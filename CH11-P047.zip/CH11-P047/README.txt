SBL 1.0 resolved page rendering package
Render target: CH11-P047
Entry file: CH11-P047.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Midori-Production-Academy.png
  Assets/Adnil-production-sheet.png
  Assets/Midori-Academy-Uniform-Production-Sheet.png
  Assets/Academy-Uniform-Female.png
  Assets/Naandeen-production-sheet.png
  Assets/Ashiba-Academy-Campus-Reference-Sheet.png
  Assets/Zarleen-age-19-20.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
