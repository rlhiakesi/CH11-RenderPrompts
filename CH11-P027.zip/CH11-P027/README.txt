SBL 1.0 resolved page rendering package
Render target: CH11-P027
Entry file: CH11-P027.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Adnil-production-sheet.png
  Assets/Midori-Temple-Robes.png
  Assets/Midori-Production-Academy.png
  Assets/Academy-Uniform-Female.png
  Assets/Ashire-Character-Sheet.png
  Assets/Ashiba-Academy-Assembly-Hall-Podium-Reference-Sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
